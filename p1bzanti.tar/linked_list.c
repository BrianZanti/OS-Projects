#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/list.h>

struct birthday {
	int day; 
	int month;
	int year;
	struct list_head list;
} *b1, *b2, *b3, *b4, *b5;
static LIST_HEAD(birthday_list);
/* This function is called when the module is loaded. */
int simple_init(void)
{
	printk(KERN_INFO "Loading Module\n");	


	b1 = kmalloc(sizeof(*b1), GFP_KERNEL);
	b1->day = 2;
	b1->month = 1;
	b1->year = 1994;
	INIT_LIST_HEAD(&(b1->list));
	list_add_tail(&(b1->list), &birthday_list);


	b2 = kmalloc(sizeof(*b2), GFP_KERNEL);
	b2->day = 2;
	b2->month = 2;
	b2->year = 1994;
	INIT_LIST_HEAD(&(b2->list));
	list_add_tail(&(b2->list), &birthday_list);


	b3 = kmalloc(sizeof(*b3), GFP_KERNEL);
	b3->day = 10;
	b3->month = 20;
	b3->year = 1993;
	INIT_LIST_HEAD(&(b3->list));
	list_add_tail(&(b3->list), &birthday_list);


	b4 = kmalloc(sizeof(*b4), GFP_KERNEL);
	b4->day = 3;
	b4->month = 20;
	b4->year = 1994;
	INIT_LIST_HEAD(&(b4->list));
	list_add_tail(&(b4->list), &birthday_list);


	b5 = kmalloc(sizeof(*b5), GFP_KERNEL);
	b5->day = 9;
	b5->month = 11;
	b5->year = 1994;
	INIT_LIST_HEAD(&(b5->list));
	list_add_tail(&(b5->list), &birthday_list);

	list_for_each_entry(b1, &birthday_list, list){
		printk(KERN_INFO "%d/%d/%d\n", b1->month, b1->day, b1->year);
	}
	return 0;
}

/* This function is called when the module is removed. */
void simple_exit(void) {
	

	list_for_each_entry_safe(b1,b2,&birthday_list,list){		
		printk(KERN_INFO "Removing: %d/%d/%d\n", b1->month, b1->day, b1->year);
		list_del(&b1->list);
		kfree(b1);
	}
	printk(KERN_INFO "Removing Module\n");
}

/* Macros for registering module entry and exit points. */
module_init( simple_init );
module_exit( simple_exit );

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Simple Module");
MODULE_AUTHOR("SGG");

